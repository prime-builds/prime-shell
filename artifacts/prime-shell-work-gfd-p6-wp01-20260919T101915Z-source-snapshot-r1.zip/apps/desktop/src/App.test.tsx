import { cleanup, render, screen, waitFor } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import App from "./App";
import { router } from "./shell/routes";
import { useTaskStore } from "./shell/state/useTaskStore";

const { invoke, listen } = vi.hoisted(() => ({
  invoke: vi.fn(),
  listen: vi.fn(),
}));

vi.mock("@tauri-apps/api/core", () => ({ invoke }));
vi.mock("@tauri-apps/api/event", () => ({ listen }));

const defaultSettings = {
  schemaVersion: 1,
  revision: 0,
  appearance: {
    themeMode: "system",
    accentMode: { mode: "default" },
    density: "comfortable",
    materialPreference: "system",
  },
  layout: {
    schemaVersion: 1,
    sidebarWidth: 280,
    sidebarCollapsed: false,
    inspectorWidth: 340,
    inspectorOpen: true,
    bottomPanelHeightRatio: 0.3,
    bottomPanelOpen: false,
    activeNavigationId: "workspace",
  },
  documentAnalysis: {
    maxTopTerms: 20,
  },
  textUtility: {
    defaultMode: "uppercase",
  },
  status: {
    state: "healthy",
  },
};

const handleBaseCommands = (command: string) => {
  if (command === "get_settings") {
    return Promise.resolve(defaultSettings);
  }
  if (command === "save_settings") {
    return Promise.resolve();
  }
  if (command === "get_theme_state") {
    return Promise.resolve({
      systemTheme: "light",
      systemAccent: null,
      materialCapabilities: {
        mica: true,
        micaAlt: false,
        transparencyEnabled: true,
        forcedColors: false,
        reducedTransparency: false,
      },
    });
  }
  if (command === "sync_native_window_theme") {
    return Promise.resolve();
  }
  if (command === "runtime_probe_config") {
    return Promise.resolve({ enabled: false, evidencePath: null });
  }
  if (command === "backend_status") {
    return Promise.resolve({
      state: "ready",
      ready: true,
      backendVersion: "0.1.0",
      circuitOpen: false,
    });
  }
  if (command === "reset_settings_section") {
    return Promise.resolve(defaultSettings);
  }
  if (command === "reset_setting") {
    return Promise.resolve(defaultSettings);
  }
  if (command === "reset_all_settings") {
    return Promise.resolve(defaultSettings);
  }
  if (command === "get_shell_layout_preferences") {
    return Promise.resolve(defaultSettings.layout);
  }
  if (command === "save_shell_layout_preferences") {
    return Promise.resolve();
  }
  if (command === "reset_shell_layout_preferences") {
    return Promise.resolve(defaultSettings.layout);
  }
  if (command === "get_task_snapshot") {
    return Promise.resolve(null);
  }
  return undefined;
};

beforeEach(async () => {
  useTaskStore.getState().reset();
  window.location.hash = "#/";
  await router.navigate("/");
  invoke.mockReset();
  listen.mockReset();
  listen.mockResolvedValue(() => {});

  window.matchMedia = vi.fn().mockReturnValue({
    matches: false,
    addEventListener: vi.fn(),
    removeEventListener: vi.fn(),
  });

  // Default handlers for base commands
  invoke.mockImplementation((command: string) => {
    const base = handleBaseCommands(command);
    if (base !== undefined) return base;
    return Promise.resolve();
  });
});

afterEach(cleanup);

describe("Prime Shell Desktop UI & Baseline Operations", () => {
  it("renders backend status and handles echo command", async () => {
    invoke.mockImplementation((command: string) => {
      if (command === "backend_status") {
        return Promise.resolve({
          state: "ready",
          ready: true,
          backendVersion: "0.1.0",
          circuitOpen: false,
        });
      }
      if (command === "runtime_probe_config") {
        return Promise.resolve({ enabled: false, evidencePath: null });
      }
      if (command === "get_theme_state") {
        return Promise.resolve({
          systemTheme: "light",
          systemAccent: null,
          materialCapabilities: {
            mica: true,
            micaAlt: false,
            transparencyEnabled: true,
            forcedColors: false,
            reducedTransparency: false,
          },
        });
      }
      if (command === "sync_native_window_theme") {
        return Promise.resolve();
      }
      if (command === "echo_text") {
        return Promise.resolve({ text: "مرحبا 👋", traceId: "trace-1" });
      }
      return Promise.reject(new Error(`Unexpected command: ${command}`));
    });

    render(<App />);
    expect(await screen.findByText("Ready")).toBeInTheDocument();

    const input = screen.getByLabelText("Unicode text");
    await userEvent.clear(input);
    await userEvent.type(input, "مرحبا 👋");
    await userEvent.click(screen.getByRole("button", { name: "Echo" }));

    expect(await screen.findByText("مرحبا 👋")).toBeInTheDocument();
    expect(invoke).toHaveBeenCalledWith("echo_text", {
      text: "مرحبا 👋",
    });
  });

  it("starts count task and cancels it", async () => {
    let eventCallback: ((event: unknown) => void) | null = null;
    listen.mockImplementation((name: string, cb: (event: unknown) => void) => {
      if (name === "task-event") {
        eventCallback = cb;
      }
      return Promise.resolve(() => {});
    });

    invoke.mockImplementation((command: string) => {
      if (command === "backend_status") {
        return Promise.resolve({
          state: "ready",
          ready: true,
          backendVersion: "0.1.0",
          circuitOpen: false,
        });
      }
      if (command === "runtime_probe_config") {
        return Promise.resolve({ enabled: false, evidencePath: null });
      }
      if (command === "get_theme_state") {
        return Promise.resolve({
          systemTheme: "light",
          systemAccent: null,
          materialCapabilities: {
            mica: true,
            micaAlt: false,
            transparencyEnabled: true,
            forcedColors: false,
            reducedTransparency: false,
          },
        });
      }
      if (command === "sync_native_window_theme") {
        return Promise.resolve();
      }
      if (command === "start_count_task") {
        return Promise.resolve("task-test-42");
      }
      if (command === "cancel_task") {
        setTimeout(() => {
          if (eventCallback) {
            eventCallback({
              payload: {
                protocol: "generic-app",
                kind: "event",
                requestId: "cancel-1",
                traceId: "trace-1",
                taskId: "task-test-42",
                sequence: 5,
                event: "terminal",
                payload: {
                  status: "Cancelled",
                  completed: 3,
                },
              },
            });
          }
        }, 10);
        return Promise.resolve({
          protocol: "generic-app",
          kind: "ack",
          requestId: "cancel-1",
          traceId: "trace-1",
          taskId: "task-test-42",
          status: "cancelling",
        });
      }
      return Promise.reject(new Error(`Unexpected command: ${command}`));
    });

    render(<App />);
    expect(await screen.findByText("Ready")).toBeInTheDocument();

    const startBtn = screen.getByRole("button", { name: "Start Count Task" });
    await userEvent.click(startBtn);

    await waitFor(() => {
      expect(invoke).toHaveBeenCalledWith("start_count_task", {
        target: 20,
        delayMs: 50,
      });
    });

    if (eventCallback) {
      (eventCallback as (event: unknown) => void)({
        payload: {
          protocol: "generic-app",
          kind: "event",
          requestId: "req-1",
          traceId: "trace-1",
          taskId: "task-test-42",
          sequence: 1,
          event: "progress",
          payload: {
            current: 5,
            target: 20,
          },
        },
      });
    }

    expect(await screen.findByText("Progress: 5 / 20")).toBeInTheDocument();

    const cancelBtn = screen.getByRole("button", { name: "Cancel Task" });
    await userEvent.click(cancelBtn);

    await waitFor(() => {
      expect(invoke).toHaveBeenCalledWith("cancel_task", {
        taskId: "task-test-42",
      });
    });

    expect(await screen.findByText("Task terminated with state: Cancelled")).toBeInTheDocument();
  });

  it("shows open circuit badge and allows backend reset", async () => {
    invoke.mockImplementation((command: string) => {
      if (command === "backend_status") {
        return Promise.resolve({
          state: "faulted",
          ready: false,
          backendVersion: "0.1.0",
          circuitOpen: true,
        });
      }
      if (command === "runtime_probe_config") {
        return Promise.resolve({ enabled: false, evidencePath: null });
      }
      if (command === "get_theme_state") {
        return Promise.resolve({
          systemTheme: "light",
          systemAccent: null,
          materialCapabilities: {
            mica: true,
            micaAlt: false,
            transparencyEnabled: true,
            forcedColors: false,
            reducedTransparency: false,
          },
        });
      }
      if (command === "sync_native_window_theme") {
        return Promise.resolve();
      }
      if (command === "reset_backend") {
        return Promise.resolve({
          state: "ready",
          ready: true,
          backendVersion: "0.1.0",
          circuitOpen: false,
        });
      }
      return Promise.reject(new Error(`Unexpected command: ${command}`));
    });

    render(<App />);
    expect(await screen.findByText("Circuit: OPEN")).toBeInTheDocument();
    expect(screen.getByText("Faulted")).toBeInTheDocument();

    const resetBtn = screen.getByRole("button", { name: "Reset Backend" });
    await userEvent.click(resetBtn);

    await waitFor(() => {
      expect(invoke).toHaveBeenCalledWith("reset_backend");
    });
    expect(await screen.findByText("Backend reset completed.")).toBeInTheDocument();
  });
});

describe("Phase 2 — Theme, Tokens, and Accessibility Foundation", () => {
  it("switches theme modes (System, Light, Dark) and coordinates native window theme", async () => {
    render(<App />);

    const darkBtn = screen.getByTestId("theme-dark-btn");
    await userEvent.click(darkBtn);

    await waitFor(() => {
      expect(invoke).toHaveBeenCalledWith("sync_native_window_theme", {
        effectiveTheme: "dark",
        backgroundHex: "#1F1F1F",
      });
    });

    const lightBtn = screen.getByTestId("theme-light-btn");
    await userEvent.click(lightBtn);

    await waitFor(() => {
      expect(invoke).toHaveBeenCalledWith("sync_native_window_theme", {
        effectiveTheme: "light",
        backgroundHex: "#F5F5F5",
      });
    });
  });

  it("switches layout density modes between comfortable and compact", async () => {
    render(<App />);

    const compactBtn = screen.getByTestId("density-compact-btn");
    await userEvent.click(compactBtn);
    expect(compactBtn).toHaveAttribute("aria-pressed", "true");

    const comfortableBtn = screen.getByTestId("density-comfortable-btn");
    await userEvent.click(comfortableBtn);
    expect(comfortableBtn).toHaveAttribute("aria-pressed", "true");
  });

  it("handles custom accent seed generation and rejects invalid seeds", async () => {
    render(<App />);

    const seedInput = screen.getByTestId("custom-seed-input");
    const applyBtn = screen.getByTestId("apply-custom-seed-btn");

    // Invalid near-white seed
    await userEvent.clear(seedInput);
    await userEvent.type(seedInput, "#FFFFFF");
    await userEvent.click(applyBtn);

    expect(await screen.findByText(/too light/i)).toBeInTheDocument();

    // Valid seed color
    await userEvent.clear(seedInput);
    await userEvent.type(seedInput, "#107C41");
    await userEvent.click(applyBtn);

    await waitFor(() => {
      expect(screen.queryByText(/too light/i)).not.toBeInTheDocument();
    });
  });

  it("renders portals (menu, tooltip, dialog) with theme inheritance and zero CSP violations", async () => {
    render(<App />);

    // Tooltip trigger
    const tooltipBtn = screen.getByTestId("tooltip-portal-trigger");
    expect(tooltipBtn).toBeInTheDocument();

    // Menu portal trigger
    const menuBtn = screen.getByTestId("menu-portal-trigger");
    await userEvent.click(menuBtn);
    expect(await screen.findByTestId("menu-item-1")).toBeInTheDocument();

    // Dialog portal trigger
    const dialogBtn = screen.getByTestId("dialog-portal-trigger");
    await userEvent.click(dialogBtn);
    expect(await screen.findByTestId("dialog-portal-surface")).toBeInTheDocument();

    // CSP violation verification element
    const cspCounter = screen.getByTestId("csp-violation-count");
    expect(cspCounter).toHaveAttribute("data-count", "0");
  });

  it("supports keyboard navigation and focus indicators across interactive elements", async () => {
    render(<App />);

    const focusTarget = screen.getByTestId("dual-tone-focus");
    expect(focusTarget).toHaveAttribute("tabIndex", "0");

    focusTarget.focus();
    expect(document.activeElement).toBe(focusTarget);

    // Status communications pair text and icons (never color alone)
    expect(screen.getByTestId("status-danger")).toHaveTextContent("Danger:");
    expect(screen.getByTestId("status-success")).toHaveTextContent("Success:");
    expect(screen.getByTestId("status-warning")).toHaveTextContent("Warning:");
  });
});

describe("Phase 2 — Responsive Application Shell (GFD-P2-WP02)", () => {
  it("renders full shell structure with TitleBar, NavigationRail, Workspace, and StatusBar", async () => {
    render(<App />);

    // App shell root
    expect(await screen.findByTestId("prime-app-shell")).toBeInTheDocument();

    // Title bar
    expect(screen.getByLabelText("Application Title Bar")).toBeInTheDocument();
    expect(screen.getAllByText("Prime Shell Desktop").length).toBeGreaterThanOrEqual(1);

    // Navigation Rail
    expect(screen.getByLabelText("Main Navigation")).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Workspace" })).toBeInTheDocument();
    expect(screen.getByRole("button", { name: "Settings" })).toBeInTheDocument();

    // Workspace host
    expect(screen.getByLabelText("Main Workspace")).toBeInTheDocument();

    // Status bar
    expect(screen.getByLabelText("Status Bar")).toBeInTheDocument();
    expect(screen.getByText("Backend Ready")).toBeInTheDocument();
  });

  it("navigates to Settings view and back to Workspace via navigation rail", async () => {
    render(<App />);

    const settingsNavBtn = await screen.findByRole("button", { name: "Settings" });
    await userEvent.click(settingsNavBtn);

    // Settings view rendered
    expect(await screen.findByRole("heading", { level: 1, name: "Settings" })).toBeInTheDocument();
    expect(screen.getByTestId("tab-appearance")).toBeInTheDocument();
    expect(screen.getByTestId("tab-layout")).toBeInTheDocument();
    expect(screen.getByTestId("tab-system")).toBeInTheDocument();

    // Navigate back to Workspace
    const backBtn = screen.getByTestId("settings-back-btn");
    await userEvent.click(backBtn);

    expect(await screen.findByText(/Responsive Application Shell \(GFD-P2-WP02\)/i)).toBeInTheDocument();
  });

  it("supports switching tabs and resetting layout preferences in Settings view", async () => {
    render(<App />);

    const settingsNavBtn = await screen.findByRole("button", { name: "Settings" });
    await userEvent.click(settingsNavBtn);

    // Switch to Layout tab
    const layoutTab = await screen.findByTestId("tab-layout");
    await userEvent.click(layoutTab);

    expect(screen.getByText("Shell Panel Dimensions & Persistence")).toBeInTheDocument();

    // Reset layout
    const resetBtn = screen.getByTestId("reset-layout-btn");
    await userEvent.click(resetBtn);

    await waitFor(() => {
      expect(invoke).toHaveBeenCalledWith("reset_settings_section", {
        section: "layout",
      });
    });
    expect(await screen.findByText("Layout preferences reset to default values.")).toBeInTheDocument();
  });

  describe("Native Document Intent & Opaque Reference Boundary (Phase 3 WP01)", () => {
    it("handles document selection, content reading, writing, and revocation", async () => {
      invoke.mockImplementation((command: string, args?: Record<string, unknown>) => {
        if (command === "runtime_probe_config") {
          return Promise.resolve({ enabled: false, evidencePath: null });
        }
        if (command === "open_document_intent") {
          return Promise.resolve({
            id: "doc-12345678",
            displayName: "report.txt",
            size: 1024,
            mediaType: "text/plain",
          });
        }
        if (command === "read_document_content") {
          expect(args).toEqual({ id: "doc-12345678" });
          return Promise.resolve("Sample document content from Rust authority");
        }
        if (command === "write_document_content") {
          expect(args).toEqual({
            id: "doc-12345678",
            content: "Updated document content",
          });
          return Promise.resolve();
        }
        if (command === "revoke_document_ref") {
          expect(args).toEqual({ id: "doc-12345678" });
          return Promise.resolve(true);
        }
        return Promise.resolve();
      });

      render(<App />);

      const openBtn = await screen.findByTestId("open-document-btn");
      await userEvent.click(openBtn);

      // Verify DocumentRef details displayed
      expect(await screen.findByTestId("document-display-name")).toHaveTextContent("report.txt");
      expect(screen.getByTestId("document-id")).toHaveTextContent("doc-12345678");
      expect(screen.getByTestId("document-size")).toHaveTextContent("1024 bytes");
      expect(screen.getByTestId("document-media-type")).toHaveTextContent("text/plain");

      // Read Content
      const readBtn = screen.getByTestId("read-content-btn");
      await userEvent.click(readBtn);

      const textarea = await screen.findByTestId("document-content-textarea");
      expect(textarea).toHaveValue("Sample document content from Rust authority");

      // Edit Content and Save
      await userEvent.clear(textarea);
      await userEvent.type(textarea, "Updated document content");
      const saveBtn = screen.getByTestId("write-content-btn");
      await userEvent.click(saveBtn);

      await waitFor(() => {
        expect(invoke).toHaveBeenCalledWith("write_document_content", {
          id: "doc-12345678",
          content: "Updated document content",
        });
      });

      // Revoke Reference
      const revokeBtn = screen.getByTestId("revoke-document-btn");
      await userEvent.click(revokeBtn);

      await waitFor(() => {
        expect(screen.queryByTestId("document-ref-details")).not.toBeInTheDocument();
      });
    });

    it("handles file picker cancellation cleanly", async () => {
      invoke.mockImplementation((command: string) => {
        if (command === "runtime_probe_config") {
          return Promise.resolve({ enabled: false, evidencePath: null });
        }
        if (command === "open_document_intent") {
          return Promise.resolve(null);
        }
        return Promise.resolve();
      });

      render(<App />);

      const openBtn = await screen.findByTestId("open-document-btn");
      await userEvent.click(openBtn);

      expect(await screen.findByTestId("picker-cancelled-msg")).toHaveTextContent("File selection cancelled by user.");
      expect(screen.queryByTestId("document-ref-details")).not.toBeInTheDocument();
    });

    it("handles native intent error safely without path leakage", async () => {
      invoke.mockImplementation((command: string) => {
        if (command === "runtime_probe_config") {
          return Promise.resolve({ enabled: false, evidencePath: null });
        }
        if (command === "open_document_intent") {
          return Promise.reject({
            code: "AUTHORIZATION_ERROR",
            message: "The requested document is not accessible.",
            traceId: "trace-auth-err",
          });
        }
        return Promise.resolve();
      });

      render(<App />);

      const openBtn = await screen.findByTestId("open-document-btn");
      await userEvent.click(openBtn);

      expect(await screen.findByTestId("document-error")).toHaveTextContent(
        "Error: The requested document is not accessible.",
      );
      expect(screen.queryByTestId("document-ref-details")).not.toBeInTheDocument();
    });
  });

  describe("Productized Task Runtime & Snapshot State (Phase 3 WP02)", () => {
    it("restores active task state from Rust snapshot on mount", async () => {
      invoke.mockImplementation((command: string) => {
        if (command === "get_task_snapshot") {
          return Promise.resolve({
            taskId: "task-restored-99",
            operation: "spike.count",
            status: "Running",
            current: 15,
            target: 50,
            error: null,
            createdAt: "2026-09-19T07:24:41Z",
            updatedAt: "2026-09-19T07:24:43Z",
          });
        }
        if (command === "runtime_probe_config") {
          return Promise.resolve({ enabled: false, evidencePath: null });
        }
        if (command === "backend_status") {
          return Promise.resolve({
            state: "busy",
            ready: false,
            backendVersion: "0.1.0",
            circuitOpen: false,
          });
        }
        if (command === "get_theme_state") {
          return Promise.resolve({
            systemTheme: "light",
            systemAccent: null,
            materialCapabilities: {
              mica: true,
              micaAlt: false,
              transparencyEnabled: true,
              forcedColors: false,
              reducedTransparency: false,
            },
          });
        }
        if (command === "get_shell_layout_preferences") {
          return Promise.resolve({
            schemaVersion: 1,
            sidebarWidth: 280,
            sidebarCollapsed: false,
            inspectorWidth: 340,
            inspectorOpen: true,
            bottomPanelHeightRatio: 0.3,
            bottomPanelOpen: false,
            activeNavigationId: "workspace",
          });
        }
        return Promise.resolve();
      });

      render(<App />);

      expect(await screen.findByText("Task ID: task-restored-99")).toBeInTheDocument();
      expect(screen.getByText("Progress: 15 / 50")).toBeInTheDocument();
      expect(screen.getByText("Running")).toBeInTheDocument();
    });

    it("handles task progress and completion events via task store", async () => {
      let eventCallback: ((event: unknown) => void) | null = null;
      listen.mockImplementation((name: string, cb: (event: unknown) => void) => {
        if (name === "task-event") {
          eventCallback = cb;
        }
        return Promise.resolve(() => {});
      });

      invoke.mockImplementation((command: string) => {
        if (command === "runtime_probe_config") {
          return Promise.resolve({ enabled: false, evidencePath: null });
        }
        if (command === "start_count_task") {
          return Promise.resolve("task-runtime-1");
        }
        if (command === "get_task_snapshot") {
          return Promise.resolve(null);
        }
        if (command === "backend_status") {
          return Promise.resolve({
            state: "ready",
            ready: true,
            backendVersion: "0.1.0",
            circuitOpen: false,
          });
        }
        if (command === "get_theme_state") {
          return Promise.resolve({
            systemTheme: "light",
            systemAccent: null,
            materialCapabilities: {
              mica: true,
              micaAlt: false,
              transparencyEnabled: true,
              forcedColors: false,
              reducedTransparency: false,
            },
          });
        }
        if (command === "get_shell_layout_preferences") {
          return Promise.resolve({
            schemaVersion: 1,
            sidebarWidth: 280,
            sidebarCollapsed: false,
            inspectorWidth: 340,
            inspectorOpen: true,
            bottomPanelHeightRatio: 0.3,
            bottomPanelOpen: false,
            activeNavigationId: "workspace",
          });
        }
        return Promise.resolve();
      });

      render(<App />);

      const startBtn = await screen.findByRole("button", { name: "Start Count Task" });
      await userEvent.click(startBtn);

      expect(await screen.findByText("Task ID: task-runtime-1")).toBeInTheDocument();

      // Emit progress event
      if (eventCallback) {
        (eventCallback as (event: unknown) => void)({
          payload: {
            protocol: "generic-app",
            kind: "event",
            requestId: "req-1",
            traceId: "trace-1",
            taskId: "task-runtime-1",
            sequence: 1,
            event: "progress",
            payload: { current: 10, target: 20 },
          },
        });
      }

      expect(await screen.findByText("Progress: 10 / 20")).toBeInTheDocument();

      // Emit terminal event
      if (eventCallback) {
        (eventCallback as (event: unknown) => void)({
          payload: {
            protocol: "generic-app",
            kind: "event",
            requestId: "req-1",
            traceId: "trace-1",
            taskId: "task-runtime-1",
            sequence: 2,
            event: "terminal",
            payload: { current: 20, target: 20, status: "Succeeded", completed: 20 },
          },
        });
      }

      expect(await screen.findByText("Task terminated with state: Succeeded")).toBeInTheDocument();
    });
  });
});


